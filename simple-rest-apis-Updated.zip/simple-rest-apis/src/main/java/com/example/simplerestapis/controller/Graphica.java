package com.example.simplerestapis.controller;

import org.json.simple.JSONObject;
import org.openqa.selenium.WebDriver;

public class Graphica
{
	static WebDriver driver = null;

	@SuppressWarnings("unchecked")
	public static JSONObject graphicaValidator(WebDriver getDriver) throws Exception
	{	
		JSONObject json_send = new JSONObject();
		try
		{
			driver = getDriver;
			TableParser objTableParser = new TableParser(driver);
			GraphParser objGraphParser = new GraphParser();

			//Validate Rendering
			if(objGraphParser.validateGraphRendering())
				json_send.put("Graph Rendering", "Passed");
			else
				json_send.put("Graph Rendering", "Error");
			
			//Validate Data
			if(objTableParser.validateGraphData())
				json_send.put("Data Validation", "Passed");
			else
				json_send.put("Data Validation", "Error");
			
			//Validate Consistency
			if(objTableParser.validateGraphConsistency())
				json_send.put("Data Consistency", "Passed");
			else
				json_send.put("Data Consistency", "Error");
			
			//Add JSON data
			JSONObject output_data = new JSONObject(GraphParser.graph_Bars_Labels);
			json_send.put("Data Exported", output_data);
			return json_send;
		}
		catch (Exception e)
		{
			System.out.println("Exception graphicaValidator - " + e.getMessage());
			throw new Exception(e.getMessage());
		}
	}
}
