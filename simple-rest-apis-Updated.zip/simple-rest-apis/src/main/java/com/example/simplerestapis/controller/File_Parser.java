package com.example.simplerestapis.controller;

import java.io.FileReader;
import java.io.Reader;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class File_Parser {

	public String getCredentials(String key) throws Exception
	{
		String value = null;
		try
		{
			JSONParser parser = new JSONParser();
			Reader reader = new FileReader("credentials.json");

			JSONObject jsonObject = (JSONObject) parser.parse(reader);
			value = jsonObject.get(key).toString();
			return value;
		}
		catch(Exception e)
		{
			System.out.println("Exception getCredentials - " + e.getMessage());
			throw new Exception("Error while getting credentials.");
		}
	}

	public String getURL() throws Exception
	{
		String url = null;
		try
		{
			JSONParser parser = new JSONParser();
			Reader reader = new FileReader("credentials.json");

			JSONObject jsonObject = (JSONObject) parser.parse(reader);
			String system = jsonObject.get("System").toString();
			String client = jsonObject.get("Client").toString();
			String app = jsonObject.get("App").toString();

			url = "https://"+system+"-"+client+".wdf.sap.corp/ui#"+app;
			return url;
		}
		catch(Exception e)
		{
			System.out.println("Exception getURL - " + e.getMessage());
			throw new Exception("Error while getting URL.");
		}
	}
}
