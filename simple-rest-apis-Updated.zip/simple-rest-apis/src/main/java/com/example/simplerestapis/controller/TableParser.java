package com.example.simplerestapis.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.json.simple.JSONObject;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TableParser {

	private static SeleniumHelper objSeleniumHelper = null;
	private static GraphParser objGraphParser = null;
	private static WebDriver driver = null;
	private static boolean dataExtracted = false;

	//Hashmap to store table and pie chart data
	private HashMap<String, HashMap<String, String>> tableValueMap = new HashMap<String, HashMap<String, String>>();
	private HashMap<String, HashMap<String, String>> tableValuePercentageMap = new HashMap<String, HashMap<String, String>>();
	private HashMap<String, HashMap<String, String>> pieValueMap = new HashMap<String, HashMap<String, String>>();

	public TableParser(WebDriver getDriver) {
		driver = getDriver;
		objSeleniumHelper = new SeleniumHelper();
		objGraphParser = new GraphParser();
	}

	@SuppressWarnings("unchecked")
	public boolean validateGraphData() throws Exception
	{
		try
		{
			//Extract data from piechart and table
			extractTableAndPieChartData();

			HTMLOutputWriter.createTable("Graph Data");

			//Validate Graph Data
			System.out.println();
			System.out.println("--------------Verfying Column Chart Data with Table-------------");
			System.out.println();
			if(!tableValueMap.isEmpty())
			{	
				for(int i = 0; i < GraphParser.xAxis_Label.size(); i++)
				{
					String forLabel = GraphParser.xAxis_Label.get(i);						
					HashMap<String, String> tableLegendForLabel = tableValueMap.get(forLabel);
					HashMap<String, String> barLegendForLabel = GraphParser.graph_Bars_Labels.get(forLabel);

					//Create JSON Object
					JSONObject objLegendDetails = new JSONObject();

					for(int j = 0; j < GraphParser.legend_Groups.size(); j++)
					{	
						String forLegendGroup = GraphParser.legend_Groups.get(j);	
						String graphLabel = barLegendForLabel.get(forLegendGroup);
						String tableValues = tableLegendForLabel.get(forLegendGroup);

						//Add to JSON
						objLegendDetails.put(forLegendGroup, graphLabel);

						String[] roundedOffTableValue = NumberConverter.roundOffNumber(tableValues);
						//System.out.println(Arrays.toString(roundedOffTableValue));

						graphLabel = graphLabel.replaceAll("\\,", ".");	
						//System.out.println(graphLabel);

						if(Arrays.stream(roundedOffTableValue).parallel().anyMatch(graphLabel::contains))	
						{
							HTMLOutputWriter.insertRow("Graph Data", forLegendGroup + " - '" + graphLabel + "' for " + forLabel, "Data Correct", false, 1);
							System.out.println("Column Chart : " + forLegendGroup + " - '" + graphLabel + "' for " + forLabel + "' is matching with table data.");
						}
						else
						{
							HTMLOutputWriter.insertRow("Graph Data", forLegendGroup + " - '" + graphLabel + "' for " + forLabel, "Data Incorrect", false, 0);
							throw new Exception("Column Chart : " + forLegendGroup + " - '" + graphLabel + "' for " + forLabel + "' is NOT matching with table data.");		
						}
					}
					System.out.println();
				}
			}
			System.out.println("------------------Column Chart Data Validated-------------------");
			System.out.println();
			HTMLOutputWriter.closeTable(1);
			return true;
		}
		catch(Exception e)
		{
			HTMLOutputWriter.closeTable(0);
			System.out.println("Exception validateGraphData - " + e.getMessage());
			throw new Exception("Graph Data Failed - " + e.getMessage());
		}
	}

	public boolean validateGraphConsistency() throws Exception
	{
		try
		{
			//Extract data from pie chart and table
			extractTableAndPieChartData();

			HTMLOutputWriter.createTable("Graph Consistency");

			//Validate Graph consistency across other graph
			System.out.println("--------------Verifying Pie Chart Data Consistency--------------");
			System.out.println();
			if(!pieValueMap.isEmpty())
			{
				for(int i = 0; i < GraphParser.xAxis_Label.size(); i++)
				{
					String forLabel = GraphParser.xAxis_Label.get(i);						
					HashMap<String, String> pieLegendForLabel = pieValueMap.get(forLabel);
					HashMap<String, String> tablePercentForLabel = tableValuePercentageMap.get(forLabel);					

					for(int j = 0; j < GraphParser.legend_Groups.size(); j++)
					{	
						String forLegendGroup = GraphParser.legend_Groups.get(j);	
						String pieLabel = pieLegendForLabel.get(forLegendGroup);
						String tablePercentValues = tablePercentForLabel.get(forLegendGroup);

						if(pieLabel.equals(tablePercentValues))
						{
							HTMLOutputWriter.insertRow("Graph Consistency (PIE)", forLegendGroup + " - '" + pieLabel + "' for " + forLabel, "Data Consistent", false, 1);
							System.out.println("Pie Chart : " + forLegendGroup + " - '" + pieLabel + "' for '" + forLabel + "' is consistent with table and column chart.");
						}
						else
						{
							HTMLOutputWriter.insertRow("Graph Consistency (PIE)", forLegendGroup + " - '" + pieLabel + "' for " + forLabel, "Data Consistent", false, 0);
							throw new Exception("Pie Chart : " + forLegendGroup + " - '" + pieLabel + "' for '" + forLabel + "' is NOT consistent with table and column chart.");
						}
					}
					System.out.println();
				}
			}
			dataExtracted = false;
			System.out.println("-----------------Pie Chart Consistency Validated----------------");
			System.out.println();
			HTMLOutputWriter.closeTable(1);
			return true;
		}
		catch(Exception e)
		{
			HTMLOutputWriter.closeTable(0);
			System.out.println("Exception validateGraphConsistency - " + e.getMessage());
			throw new Exception("Graph Consistency Failed - " + e.getMessage());
		}
	}

	private void extractTableAndPieChartData() throws Exception
	{
		try
		{	
			if(!dataExtracted)
			{
				//Store output to JSON
				//objCategoryJSON.put("Legend Groups", GraphParser.legend_Groups);
				//objCategoryJSON.put(GraphParser.xAxis_Category, GraphParser.xAxis_Label);
				//objCategoryJSON.put("Y Axis Label", GraphParser.yAxis_Label);

				//Click on Chart and Table View
				Document doc = objSeleniumHelper.getJsoupDom();
				doc = objSeleniumHelper.getJsoupDom();
				Element chartTableViewBtn = doc.select("li[title='Chart and Table View']").first();
				//Element chartViewBtn = doc.select("li[title='Chart View']").first();
				//Element tableViewBtn = doc.select("li[title='Table View']").first();
				String chartTableViewBtnID = chartTableViewBtn.attr("id");
				objSeleniumHelper.click(chartTableViewBtnID, "Chart and Table View");

				//Find Setting buttons ID
				String settingBtnTable = null;
				String settingBtnChart = null;
				Elements settingBtn = doc.select("button[title='Settings']");
				for (Element button : settingBtn) 
				{
					String id = button.attr("id");
					if(id.contains("table")) settingBtnTable = id;
					else if(id.contains("chart")) settingBtnChart = id;
				}

				//Select legend group columns in settings 
				changeSettingsColumn(settingBtnTable, GraphParser.legend_Groups);

				//Change view to Pie Chart
				changeGraphType("Pie Chart");

				//Filter table by X-Axis category and read data
				for(int i = 0; i < GraphParser.xAxis_Label.size(); i++)
				{	
					System.out.println("\nApply Filter Category " + GraphParser.xAxis_Category + " for - " + GraphParser.xAxis_Label.get(i));
					String forLabel = GraphParser.xAxis_Label.get(i);
					changeSettingsFilter(settingBtnTable, GraphParser.xAxis_Category, forLabel);					
					changeSettingsFilter(settingBtnChart, GraphParser.xAxis_Category, forLabel);

					//Read values from Table
					HashMap<String, String> tableValues = getValuesFromTable();				
					tableValueMap.put(forLabel, tableValues);
					//System.out.println(tableValues);

					//Read values from Pie-Chart
					HashMap<String, String> pieGraphValues = objGraphParser.getValuesFromPieChart();
					pieValueMap.put(forLabel, pieGraphValues);
					//System.out.println(pieGraphValues);

					//Covert Table values to percentage
					HashMap<String, String> tableValuesInPercent = NumberConverter.convertToPercent(tableValues, GraphParser.legend_Groups);
					tableValuePercentageMap.put(forLabel, tableValuesInPercent);
					//System.out.println(tableValuesInPercent);
				}
				dataExtracted = true;
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception extractTableAndPieChartData - " + e.getMessage());
			throw new Exception("Not able to apply filter for Table and Pie Chart.");
		}
	}

	private HashMap<String, String> getValuesFromTable() throws Exception
	{
		System.out.println();
		System.out.println("Getting values from TABLE.");
		HashMap<String, String> tableValues = new HashMap<String, String>();
		try
		{
			objSeleniumHelper.waitForBusyIndicatorToDisappear();
			Document doc = objSeleniumHelper.getJsoupDom();
			Elements tableView = doc.select("table[id$='-fixrow-bottom']");
			if(!tableView.isEmpty()) 
			{
				Elements tableColumns = tableView.select("tbody > tr > td");

				for(Element column : tableColumns) 
				{
					Elements value = column.select("span");
					String textVal = value.text();					
					textVal = textVal.replaceAll("[^,-a-zA-Z0-9.\\s+]", "");

					if(!textVal.isEmpty()) {
						String ariaLabelled = column.attr("aria-labelledby");
						String tableHead = doc.getElementById(ariaLabelled).text();
						System.out.println(tableHead + " " + textVal);
						tableValues.put(tableHead, textVal);
					}
				}
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception getValuesFromTable - " + e.getMessage());
			throw new Exception("Not able to read data from Table.");
		}
		return tableValues;
	}

	private Element getSettingPopup()
	{
		Element popupSetting = null;
		Document doc = objSeleniumHelper.getJsoupDom();
		Elements setting_popup = doc.select("div[data-sap-ui-popup]");

		for(Element popup : setting_popup)
		{
			//Get the label of popup
			String popupLabel = null;
			String ariaLabelledBy = popup.attr("aria-labelledby");

			if(ariaLabelledBy.contains(" "))
			{
				String popupLabelId = ariaLabelledBy.split("\\s+")[0];
				popupLabel = popup.select("[id='"+popupLabelId+"']").first().text();

				//If popup is View Settings
				if(popupLabel.toLowerCase().contains("view settings"))
				{
					popupSetting = popup;					
				}
			}
		}
		return popupSetting;
	}

	private void clickButtonsInSetting(String settingButtonID, String buttonToClick) throws Exception
	{
		try
		{
			objSeleniumHelper.click(settingButtonID, "Setting Button");

			Element setting_popup = getSettingPopup();
			Elements popupButtons = setting_popup.select("ul > li");						
			for (Element button : popupButtons) 
			{
				String buttontext = button.text();
				String buttonID = button.id();
				//System.out.println(buttontext + " - " + button.id());

				if(buttontext.equalsIgnoreCase(buttonToClick))
					driver.findElement(By.id(buttonID)).click();
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception clickButtonsInSetting - " + e.getMessage());
			throw new Exception("Not able to click "+ buttonToClick +" button in View Setting.");		
		}
	}

	private void changeSettingsFilter(String settingButtonID, String filterCategory, String filterValue) throws Exception
	{
		try
		{
			clickButtonsInSetting(settingButtonID, "filter");
			Element setting_popup = getSettingPopup();
			Element grid = setting_popup.select(".sapUiRespGrid > div").first();
			Elements inputFields = grid.select("div > div > div > input[value]");										

			//Find ComboBox and enter category
			Element combo = inputFields.select(".sapMComboBoxInner").first();
			WebElement comboElement = driver.findElement(By.id(combo.id()));
			comboElement.click();
			comboElement.sendKeys(Keys.DELETE);
			objSeleniumHelper.sendText(combo.id(), filterCategory, "Filter Category");

			//Find ComboBox and press Enter
			setting_popup = getSettingPopup();
			grid = setting_popup.select(".sapUiRespGrid > div").first();
			inputFields = grid.select("div > div > div > input[value]");	
			combo = inputFields.select(".sapMComboBoxInner").first();
			driver.findElement(By.id(combo.id())).sendKeys(Keys.RETURN);

			//Get Setting popup again as ID are changed
			setting_popup = getSettingPopup();
			grid = setting_popup.select(".sapUiRespGrid > div").first();
			inputFields = grid.select("div > div > div > input[value]");	

			//Enter input to filter
			Element value = inputFields.select("[placeholder='value']").first();
			objSeleniumHelper.sendText(value.id(), filterValue, "Filter Value");
			driver.findElement(By.id(combo.id())).sendKeys(Keys.RETURN);
			//objSeleniumHelper.pressEnter();	

			//Press OK button
			Element okButton = setting_popup.select("bdi:contains(OK)").last();
			driver.findElement(By.id(okButton.attr("id"))).click();	
			objSeleniumHelper.waitForBusyIndicatorToDisappear();
		}
		catch(Exception e)
		{
			System.out.println("Exception changeTableSettingsFilter - " + e.getMessage());
			throw new Exception("Not able to change Filter in Settings.");
		}
	}

	private void changeSettingsColumn(String settingButtonID, List<String> legendGroup) throws Exception
	{
		try
		{	
			clickButtonsInSetting(settingButtonID, "columns");
			Element setting_popup = getSettingPopup();	

			Elements rows = setting_popup.select("table > tbody > tr");
			for (Element row : rows) 
			{
				String title1 = row.attr("title");
				String title2 = row.select("td > span").text();	
				if(row.attr("aria-selected").equalsIgnoreCase("false") && (legendGroup.contains(title1) || legendGroup.contains(title2)))
				{
					Element hec = row.select("div[role='checkbox']").first();
					objSeleniumHelper.click(hec.attr("id"), "CheckBox");
					//driver.findElement(By.id(hec.attr("id"))).click();
					Thread.sleep(500);
				}
			}
			Element okButton = setting_popup.select("bdi:contains(OK)").first();
			driver.findElement(By.id(okButton.attr("id"))).click();	
			objSeleniumHelper.waitForBusyIndicatorToDisappear();
		}
		catch(Exception e)
		{
			System.out.println("Exception changeTableSettingsColumn - " + e.getMessage());
			throw new Exception("Not able to select columns in Settings.");
		}
	}

	private void changeGraphType(String graphName)
	{
		objSeleniumHelper.waitForBusyIndicatorToDisappear();
		Document doc = objSeleniumHelper.getJsoupDom();
		Element selectChartBtn = doc.select("button[title^='Selected Chart Type']").first();
		driver.findElement(By.id(selectChartBtn.id())).click();
		doc = objSeleniumHelper.getJsoupDom();
		Elements chartType = doc.select("div:containsOwn("+graphName+")");

		for( Element child : chartType){
			Elements parents = child.parents();
			for(Element parent: parents){
				if(parent.tagName().equalsIgnoreCase("li"))
				{
					//driver.findElement(By.id(parent.id())).click();
					//System.out.println(parent.id());
					objSeleniumHelper.click(parent.id(), graphName);
				} 
			}
		}
	}
}
