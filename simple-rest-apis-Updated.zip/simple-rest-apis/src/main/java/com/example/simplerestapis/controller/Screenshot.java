package com.example.simplerestapis.controller;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Screenshot 
{
	public static void takeScreenshot(WebDriver driver, String path) throws Exception
	{
		File source = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
			File DestFile = new File(path);
			FileUtils.copyFile(source, DestFile);
		}
		catch (IOException e)
		{
			System.out.println("Exception takeScreenshot - " + e.getMessage());
			throw new Exception("Not able to take screenshot.");
		}             
	} 
}
