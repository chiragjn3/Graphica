package com.example.simplerestapis.controller;

import java.awt.AWTException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.mavericks.JSON_Response;

@RestController
@ResponseStatus()
@ResponseBody
public class WebController 
{
	static WebDriver driver = null; 

	@SuppressWarnings("unchecked")
	@RequestMapping(value= "/GetFields", method = RequestMethod.POST)
	public JSON_Response api1(@RequestBody Map<String, Object> payload) 
	{
		JSON_Response output_response = new JSON_Response();
		JSONObject json_fields = new JSONObject();
		JSONObject json_fields_id = new JSONObject();
		JSONObject json_credentials = new JSONObject();
		SeleniumHelper objSeleniumHelper = new SeleniumHelper();

		try
		{
			System.out.println("***************************************************************");
			System.out.println("                      Graphica Logs Start                      ");
			System.out.println("***************************************************************");

			//Read payload from json body
			String system = (String) payload.get("System");
			String client = (String) payload.get("Client");
			String appTag = (String) payload.get("App");
			String username = (String) payload.get("UserName");
			String password = (String) payload.get("Password");

			//Write credentials to json
			json_credentials.put("System", system);
			json_credentials.put("Client", client);
			json_credentials.put("App", appTag);
			json_credentials.put("UserName", username);
			json_credentials.put("Password", password); 

			//Dump credentials
			String executionPath = System.getProperty("user.dir");
			FileWriter file = new FileWriter(executionPath + "\\credentials.json");
			file.write(json_credentials.toString());
			file.flush();
			file.close();

			//Create URL and Login
			String url = "https://" + system + "-" +client + ".wdf.sap.corp/ui#" + appTag;
			driver = objSeleniumHelper.openURL(url);
			objSeleniumHelper.login(username, password);

			//Mandatory checks
			WebController.mandatoryChecks(objSeleniumHelper);

			//Get page DOM
			Document doc = objSeleniumHelper.getJsoupDom();

			//Get all the input fields and their id with mandatory field check
			doc = objSeleniumHelper.getJsoupDom();
			Element header_div = doc.select("div[class='sapUiAFLayoutItem']").first().parent();
			Elements fields_div = header_div.children();
			for (Element fields : fields_div)
			{
				if (fields.attr("class").equals("sapUiAFLayoutItem"))
				{
					Element label = fields.select("div > div > div > label").first();
					if (label == null)
						continue;
					else
					{
						String label_text = label.text();
						Element label_div = fields.select("div").first().children().last();
						Element label_id_check = label_div.select("div > div > div > input").first();
						String label_id = label_id_check.attr("id");
						//System.out.println(label.text() + " - " + label_id);

						if (label.hasClass("sapMLabelRequired"))
						{
							json_fields.put(label_text, true);
							json_fields_id.put(label_text, label_id);
						}
						else
						{
							json_fields.put(label_text, false);
							json_fields_id.put(label_text, label_id);
						}
					}
				}
			}
			System.out.println(json_fields.toString());

			//Write fields with their ids to json
			file = new FileWriter(executionPath + "\\mandatory.json");
			file.write(json_fields_id.toString());
			file.flush();
			file.close();
		}
		catch (Exception e)
		{
			System.out.println("Exception GetFields API - " + e.getMessage());
			for(Object key: json_fields.keySet())
				json_fields.remove(key);
			json_fields.put("Error", e.getMessage());
		}
		finally
		{
			driver.quit();
			System.out.println("***************************************************************");
			System.out.println("**********************Graphica Logs Ends***********************");
			System.out.println("***************************************************************");
		}
		output_response.setMessage(json_fields.toString());
		return output_response;
	}


	@SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value= "/ValidateGraph", method = RequestMethod.POST)
	public JSON_Response api2(@RequestBody Map<String, Object> payload) throws IOException, ParseException, AWTException, InterruptedException 
	{	
		JSON_Response output_response = new JSON_Response();
		JSONObject json_send = new JSONObject();
		try
		{
			System.out.println("***************************************************************");
			System.out.println("*********************Graphica Logs Start***********************");
			System.out.println("***************************************************************");

			JSONParser parser = new JSONParser();
			File_Parser par = new File_Parser();
			SeleniumHelper objSeleniumHelper = new SeleniumHelper();

			String jsonMessage = (String) payload.get("message");
			JSONObject json_fields = (JSONObject)parser.parse(jsonMessage);	 

			//Create URL and Login
			String url = par.getURL();
			String username = par.getCredentials("UserName");
			String password = par.getCredentials("Password");
			driver = objSeleniumHelper.openURL(url);
			HTMLOutputWriter.createHTML(driver);
			objSeleniumHelper.login(username, password);

			//Mandatory Checks
			WebController.mandatoryChecks(objSeleniumHelper);

			//Read JSON file and get the IDs
			FileReader reader = new FileReader("mandatory.json");
			JSONObject json_fields_id = (JSONObject)parser.parse(reader);
			System.out.println("Reading JSON File and get IDs");
			String id = null;
			Set keys  = json_fields_id.keySet();
			Iterator iterator = keys.iterator();
			while (iterator.hasNext())
			{
				String key = (String) iterator.next();
				String value = json_fields.get(key).toString();
				if (!value.equalsIgnoreCase("false"))
				{
					//System.out.println("TrueValue"+ value);
					id = json_fields_id.get(key).toString();
					//System.out.println("Key :"+ key + "Value:"+ value);

					objSeleniumHelper.sendText(id, value, key);
				}
			}
			reader.close();

			//Click on Go button or enter
			Thread.sleep(1000);
			objSeleniumHelper.pressEnter(id);
			objSeleniumHelper.pressEnter(id);
			Document doc = objSeleniumHelper.getJsoupDom();
			Element go_button = doc.select("button[title='Go']").first();
			if(go_button != null)
			{
				String go_id = go_button.attr("id");
				objSeleniumHelper.click(go_id, "Go");
			}

			//Validate Graph
			json_send = Graphica.graphicaValidator(driver);
		}
		catch(Exception e)
		{
			System.out.println("Exception ValidateGraph API - " + e.getMessage());
			json_send.put("Error", e.getMessage());
		}
		finally
		{
			Thread.sleep(2000);
			driver.quit();
			HTMLOutputWriter.closeHTML();
			HTMLOutputWriter.cleanup();
			System.out.println("***************************************************************");
			System.out.println("                      Graphica Logs Ends                       ");
			System.out.println("***************************************************************");
		}
		output_response.setMessage(json_send.toString());
		return output_response;
	}

	//****************************************
	// Mandatory Pre-checks
	//****************************************
	public static void mandatoryChecks(SeleniumHelper objSeleniumHelper) throws Exception
	{
		try
		{
			Document doc = objSeleniumHelper.getJsoupDom();

			//Check if Header is collapsed or expanded and take action
			Element expand = doc.select("button[title='Expand header']").first();
			if(expand != null)
			{
				String header_id = expand.attr("id");
				if (driver.findElement(By.id(header_id)).isDisplayed())
				{
					objSeleniumHelper.click(header_id, "Expand Header");
				}
			}

			//Check if Compact Header is selected or not 
			Element compact_filter = doc.select("li[title='Compact Filter']").first();
			if(compact_filter != null)
			{
				String filter_id = compact_filter.attr("id");
				if (driver.findElement(By.id(filter_id)).isDisplayed())
				{
					objSeleniumHelper.click(filter_id, "Compact Filter");
				}
			}

			//Check and change view name to Standard if not done by default
			Element view_name = doc.select("div[title='Select View']").first();
			Element get_name = view_name.select("div > div > div > span").first();
			if (!(get_name.text().equalsIgnoreCase("standard")))
			{
				Element view_change = view_name.select("div").first();
				Element view_change_div = view_change.children().last();

				String view_change_button = view_change_div.select("button").first().attr("id");
				objSeleniumHelper.click(view_change_button, "View Change");
				Thread.sleep(1000);

				doc = objSeleniumHelper.getJsoupDom();
				Element view_name_div = doc.select("div[class='sapMPopoverScroll']").first();
				Elements view_names = view_name_div.select("div > div > section > ul > li");
				//System.out.println(view_names);
				for (Element view : view_names)
				{
					if (view.text().equals("Standard"))
					{
						String view_name_id = view.attr("id");
						objSeleniumHelper.click(view_name_id, "View");
					}
				}
			}
		}
		catch(Exception e)
		{
			throw new Exception("Not able to read filters information. Please try again.");
		}
	}
}


