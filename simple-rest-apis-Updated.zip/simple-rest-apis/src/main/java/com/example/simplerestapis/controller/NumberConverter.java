package com.example.simplerestapis.controller;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class NumberConverter {

	public static Float changeNumberScale(String format, String number) 
	{
		Float updatedNumber = null;
		HashMap<String, Long> numberScale = new HashMap<>();
		numberScale.put("N", (long) 1);
		numberScale.put("K", (long) 1000);
		numberScale.put("M", (long) 1000000);
		numberScale.put("B", (long) 1000000000);
		numberScale.put("T", (long) 1000000000000L);

		int firstSpaceIndex = (number.indexOf(" ") >= 0) ? number.indexOf(" ") : number.length()-1;	
		number = number.substring(0, firstSpaceIndex);
		number = number.replaceAll("[^,-a-zA-Z0-9.]", "");
		number = number.replaceAll(",",".");

		String getNumScale = number.replaceAll("[^a-zA-Z]+", "").toUpperCase();	
		if(getNumScale.isEmpty()) {	getNumScale = "N"; }
		number = number.replaceAll(getNumScale,"");

		updatedNumber = Float.parseFloat(number);
		if (numberScale.containsKey(getNumScale)) {
			if(format != getNumScale) {
				updatedNumber = (updatedNumber * numberScale.get(getNumScale)) / numberScale.get(format);
			}
		}
		return updatedNumber;
	}
	
	public static List<Float> changeNumberScale(String format, List<String> numberList) 
	{
		List<Float> updatedNumberList = new ArrayList<Float>();
		HashMap<String, Long> numberScale = new HashMap<>();
		numberScale.put("N", (long) 1);
		numberScale.put("K", (long) 1000);
		numberScale.put("M", (long) 1000000);
		numberScale.put("B", (long) 1000000000);
		numberScale.put("T", (long) 1000000000000L);

		for(String number : numberList)
		{
			String getNumScale = number.replaceAll("[^a-zA-Z]+", "").toUpperCase();	
			if(getNumScale.isEmpty()) {	getNumScale = "N"; }
				number = number.replaceAll(getNumScale,"");

			float value = Float.parseFloat(number);
			if (numberScale.containsKey(getNumScale)) {
				if(format != getNumScale) {
					value = (value * numberScale.get(getNumScale)) / numberScale.get(format);
				}
			}
			updatedNumberList.add(value);
		}
		return updatedNumberList;
	}

	private static String convertTolongFormatNumber(String number) throws Exception
	{
		number = number.replaceAll("[^0-9.,]", "");

		if(!doesMatch(number,"^[+-]?[0-9]{1,3}(?:[0-9]*(?:[.,][0-9]{0,2})?|(?:,[0-9]{3})*(?:\\.[0-9]{0,2})?|(?:\\.[0-9]{3})*(?:,[0-9]{0,2})?)$"))
			throw new Exception("Number is in wrong format " + number);

		// Replace all dots with commas
		number = number.replaceAll("\\.", ",");

		// If fractions exist, the separator must be a .
		if(number.length()>=3) {
			char[] chars = number.toCharArray();
			if(chars[chars.length-2] == ',') {
				chars[chars.length-2] = '.';
			} else if(chars[chars.length-3] == ',') {
				chars[chars.length-3] = '.';
			}
			number = new String(chars);
		}

		// Remove all commas        
		return number.replaceAll(",", "");                
	}

	public static String[] roundOffNumber(String num) throws Exception 
	{
		num = convertTolongFormatNumber(num);
		double number = Double.parseDouble(num);  
		HashMap<Integer, String> map = new HashMap<>();

		map.put(1, "K");
		map.put(2, "M");
		map.put(3, "B");
		map.put(4, "T");

		String[] value = new String[2];
		double bg = 1000.00;

		if (number < bg) 
		{
			value[0] = Double.toString(number);
			value[1] = "0";
		}
		else if(number > bg) 
		{
			while(number > bg) 
			{
				number = (Math.round(number)) / bg;
			}

			BigDecimal bd1 = new BigDecimal(number).setScale(2, RoundingMode.UP);
			double number1 = bd1.doubleValue();
			BigDecimal bd2 = new BigDecimal(number).setScale(2, RoundingMode.DOWN);
			double number2 = bd2.doubleValue();

			if((number1 % 1) == 0)
				value[0] = Integer.toString((int) number1);
			else
				value[0] = Double.toString((number1));
			
			if((number2 % 1) == 0)
				value[1] = Integer.toString((int) number2);
			else
				value[1] = Double.toString((number2));
		}
		return value;
	}

	public static HashMap<String, String> convertToPercent(HashMap<String, String> allKeys, List<String> requiredKeys) throws Exception 
	{
		HashMap<String, String> convert = new HashMap<>();
		try 
		{
			double sum = 0.00;
			//Total sum of required Keys/Legend Groups
			for (int i = 0; i < requiredKeys.size(); i++) 
			{
				String value = convertTolongFormatNumber(allKeys.get(requiredKeys.get(i)));
				double num = Double.parseDouble(value);
				sum = sum + num;
			} 

			//Percentage of each required key
			for (int i = 0; i< requiredKeys.size(); i++) 
			{
				String value = convertTolongFormatNumber(allKeys.get(requiredKeys.get(i)));
				double calcPercentage = Double.parseDouble(value);
				calcPercentage = (calcPercentage * 100.00) / sum ;
				BigDecimal bd = new BigDecimal(calcPercentage).setScale(1, RoundingMode.HALF_UP);
				calcPercentage = bd.doubleValue();
				String percentage = Double.toString((calcPercentage));
				percentage = percentage + "%";
				convert.put(requiredKeys.get(i),percentage);
			}
		}
		catch (Exception e) 
		{
			throw new Exception("Exception convertToPercent - " + e.getMessage());
		}	
		return convert;
	}

	private static boolean doesMatch(String s, String pattern) 
	{
		try 
		{
			Pattern patt = Pattern.compile(pattern, Pattern.CASE_INSENSITIVE);
			Matcher matcher = patt.matcher(s);
			return matcher.matches();
		} catch (RuntimeException e) {
			return false;
		}           
	}  	
}
