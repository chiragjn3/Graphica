package com.example.simplerestapis.controller;

import java.awt.AWTException;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SeleniumHelper {

	private static WebDriver driver = null;

	public WebDriver openURL(String url) throws Exception
	{
		try
		{
			String executionPath = System.getProperty("user.dir");
			String chromeDriverPath = executionPath + "\\chromedriver.exe";
			System.setProperty("webdriver.chrome.driver", chromeDriverPath);
			ChromeOptions options = new ChromeOptions();
			//options.addArguments("--headless");
			driver = new ChromeDriver(options);
			driver.manage().window().maximize();
			driver.get(url);
		}
		catch(Exception e)
		{
			throw new Exception("Error while loading webpage - " + e.getMessage());
		}
		return driver;
	}

	public void login(String userName, String password)
	{
		try
		{
			if(driver.findElement(By.id("USERNAME_FIELD-inner")) != null)
				sendText("USERNAME_FIELD-inner", userName, "User Name");
			if(findElementByAll("PASSWORD_FIELD-inner") != null)
				sendText("PASSWORD_FIELD-inner", password, "Password");
			if(findElementByAll("LOGIN_LINK") != null)
				click("LOGIN_LINK", "Login");
		}
		catch(Exception e)
		{
			if(findElementByAll("j_username") != null)
				sendText("j_username", userName, "User Name");
			if(findElementByAll("j_password") != null)
				sendText("j_password", password, "Password");
			if(findElementByAll("logOnFormSubmit") != null)
				click("logOnFormSubmit", "Login");
		}
		closePopup("//div[@id='help4-saml-receiver']//div//div/button");
	}

	public void sendText(String locator, String value, String label)
	{
		WebElement element = findElementByAll(locator);
		if (element != null) {
			element.sendKeys(Keys.HOME, Keys.chord(Keys.SHIFT, Keys.END), value);
			//System.out.println("Data entered '" + value + "' successfully for field " + label);
		}
		else
			throw new NoSuchElementException("Element '" + label + "' not found with locator - " + locator);
	}

	public String getText(String locator, String label)
	{
		WebElement element = findElementByAll(locator);
		if (element != null) {
			//System.out.println("Data captured '" + element.getText() + "' successfully for field " + label);
			return element.getText();
		}
		else
			throw new NoSuchElementException("Element '" + label + "' not found with locator - " + locator);
	}

	public void click(String locator, String label)
	{
		WebElement element = findElementByAll(locator);
		if (element != null) {
			element.click();
			//System.out.println("Clicked on " + label + " successful");
		}
		else
			throw new NoSuchElementException("Element '" + label + "' not found with locator - " + locator);
	}

	public void pressEnter(String locator) throws AWTException
	{
		try 
		{
			WebElement element = findElementByAll(locator);
			if (element != null) {
				element.sendKeys(Keys.RETURN);
				waitForBusyIndicatorToDisappear();
			}
			/*
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			robot.delay(2000);
			 */
		}
		catch (Exception e) {
			throw new AWTException("Not able to press enter");
		}
	}

	public void waitForBusyIndicatorToAppear() throws Exception
	{
		try
		{
			WebDriverWait wait2 = new WebDriverWait(driver, 5);
			wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'sapUiLocalBusyIndicator')]")));	
		}
		catch (Exception e)
		{
			throw new Exception("Exception waitForBusyIndicatorToAppear - " + e.getMessage());
		}
	}

	public void waitForBusyIndicatorToDisappear()
	{
		try
		{
			WebDriverWait wait3 = new WebDriverWait(driver, 10);
			wait3.until(ExpectedConditions.and(absenceOfElementLocated("//div[contains(@class,'sapUiLocalBusyIndicator')]")));
		}
		catch (Exception e)
		{
			//throw new Exception("Exception waitForBusyIndicatorToDisappear - " + e.getMessage());
		}
	}


	public Document getJsoupDom()
	{
		String html_page = driver.getPageSource();
		Document html = Jsoup.parse(html_page);
		return html;
	}

	private static ExpectedCondition<Boolean> absenceOfElementLocated(final String locator)
	{
		return new ExpectedCondition<Boolean> ()
		{
			@Override
			public Boolean apply(WebDriver driver)
			{
				try
				{
					if (driver.findElements(By.id(locator)).size() != 0)
					{
						return false;
					}
					else if (driver.findElements(By.xpath(locator)).size() != 0)
					{
						return false;
					}
					return true;
				}
				catch (NoSuchElementException e)
				{
					return true;
				}
				catch (StaleElementReferenceException e)
				{
					return true;
				}
			}
		};
	}

	private WebElement findElementByAll(final String locator)
	{
		WebElement element = null;
		try
		{
			Wait <WebDriver> wait = new FluentWait <WebDriver> (driver)
					.withTimeout(50,TimeUnit.SECONDS)
					.pollingEvery(500,TimeUnit.MILLISECONDS)
					.ignoring(NoSuchElementException.class);

			element = wait.until(new Function <WebDriver, WebElement> ()
			{
				public WebElement apply(WebDriver driver)
				{
					try
					{
						if (driver.findElements(By.id(locator)).size() != 0)
						{
							WebElement tempElement = driver.findElement(By.id(locator));
							makeElementVisible(tempElement);		
							waitForBusyIndicatorToDisappear();

							tempElement = driver.findElement(By.id(locator));
							return tempElement;
						}
						else if (driver.findElements(By.xpath(locator)).size() != 0)
						{
							WebElement tempElement = driver.findElement(By.xpath(locator));
							makeElementVisible(tempElement);		
							waitForBusyIndicatorToDisappear();

							tempElement = driver.findElement(By.xpath(locator));
							return tempElement;
						}
						return null;
					}
					catch (Exception e)
					{
						return null;
					}
				}
			});
			return element;
		}
		catch (Exception e)
		{
			return null;
		}
	}

	private void makeElementVisible(WebElement element) {
		try {
			WebDriver driver = ((RemoteWebElement)element).getWrappedDriver();

			Boolean isVisible = (Boolean)((JavascriptExecutor)driver).executeScript(
					"var elem = arguments[0],                 " +
							"  box = elem.getBoundingClientRect(),    " +
							"  cx = box.left + box.width / 2,         " +
							"  cy = box.top + box.height / 2,         " +
							"  e = document.elementFromPoint(cx, cy); " +
							"for (; e; e = e.parentElement) {         " +
							"  if (e === elem)                        " +
							"    return true;                         " +
							"}                                        " +
							"return false;                            "
							, element);

			if(!isVisible)
			{
				((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", element);
				Thread.sleep(500);
			}
		} catch (Exception e) {}
	}

	private void closePopup(String locator)
	{
		try
		{
			//System.out.println("Waiting for Popup to appear.");
			if (findElementByAll(locator) != null)
			{
				//System.out.println("Popup appeared.");
				WebDriverWait wait = new WebDriverWait(driver, 10);
				wait.until(ExpectedConditions.and(absenceOfElementLocated(locator)));
				//System.out.println("Popup closed.");
			}
		}
		catch (Exception e)
		{
			//System.out.println("Closing the popup.");
			click(locator, "Popup");
		}
	}
}
