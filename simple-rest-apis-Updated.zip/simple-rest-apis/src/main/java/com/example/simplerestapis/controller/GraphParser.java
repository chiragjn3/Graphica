package com.example.simplerestapis.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
//import java.io.PrintWriter;

public class GraphParser 
{
	public static HashMap<String, HashMap<String, String>> graph_Bars_Labels = null;
	public static String xAxis_Category = null;
	public static List<String> xAxis_Label = null;
	public static List<String> legend_Groups = null;
	private static SeleniumHelper objSeleniumHelper = null;
	//public static String yAxis_Category = null;
	//public static List<String> yAxis_Label = null;

	public GraphParser()
	{
		objSeleniumHelper = new SeleniumHelper();
	}

	public boolean validateGraphRendering() throws Exception
	{
		try
		{
			HTMLOutputWriter.createTable("Graph Rendering");
			objSeleniumHelper.waitForBusyIndicatorToDisappear();
			Document doc = objSeleniumHelper.getJsoupDom();

			//Create code file in local directory
			//PrintWriter writer = new PrintWriter("C:\\Users\\I500503\\eclipse-workspace\\ServerListen\\DomGraphComma.html", "UTF-8");
			//writer.println(doc);
			//writer.close();

			Elements graphNode = doc.select("svg");
			Elements graphMain = graphNode.select(".v-m-main");

			if(graphNode.isEmpty() || graphMain.isEmpty())
			{
				HTMLOutputWriter.insertRow("Rendering Error", "-", "No Graph/Data found", true, 0);
				throw new Exception("Graph Rendering Error : No Graph/Data found. Try adjusting the filter settings.");
			}
			else
			{
				//Element graphType = graphNode.select(".v-m-desc-title > title").first();
				//if(graphType != null && graphType.text().contains("Column Chart"))

				//Find the Legend groups in graph
				System.out.println();
				List<String> legendGroup = getLegendGroup(graphNode);
				HTMLOutputWriter.insertRow("Legend Group", "-", legendGroup.toString(), true, 1);
				System.out.println("Legend Group - " + legendGroup);
				System.out.println();

				//Find the X-Axis data
				Elements graphXAxis = graphMain.select(".v-m-xAxis");
				String xAxisCategory = getXAxisCategory(graphXAxis);
				HTMLOutputWriter.insertRow("X Axis Category", "-", xAxisCategory, false, 1);

				List<String> xAxisLabels = getXAxisLabels(graphXAxis);
				HTMLOutputWriter.insertRow("X Axis Label", "-", xAxisLabels.toString(), false, 1);

				List<String> extractedXAxisLabels = extractXAxisLabels(xAxisLabels);
				System.out.println();

				//Find the Y-Axis data
				Elements graphYAxis = graphMain.select(".v-m-yAxis");
				//String yAxisCategory = getYAxisCategory(graphYAxis);			
				List<String> yAxisLabels = getYAxisLabels(graphYAxis);

				if(xAxisLabels.isEmpty() || yAxisLabels.isEmpty())
				{
					HTMLOutputWriter.insertRow("Rendering Error", "-", "No Data found for X or Y Axis", true, 0);
					throw new Exception("Graph Rendering Error : No Data found for X or Y Axis.");
				}

				//Find the Grid Lines data
				Elements graphPlot = graphMain.select(".v-m-plot");
				List<Float> gridLinesHeight = getGridLinesHeight(graphPlot);
				List<Float> updatedGridLinesHeight = updateGridLinesHeight(yAxisLabels, gridLinesHeight);
				System.out.println("Y-Axis Labels Details - " + yAxisLabels);
				System.out.print("\n");

				//Hashmap to store graph data
				HashMap<String, HashMap<String, String>> barGraphLabelMap = new HashMap<String, HashMap<String, String>>();	
				HashMap<String, HashMap<String, Float>> barGraphLabelFormattedMap = new HashMap<String, HashMap<String, Float>>();		
				HashMap<String, HashMap<String, Float>> barGraphHeightMap = new HashMap<String, HashMap<String, Float>>();	

				//Change bar labels number scale to make it uniform (Trillion, Billion, Million, Thousands)
				String getNumScale = "";
				for(String yLabel : yAxisLabels)
				{
					getNumScale = yLabel.replaceAll("[^a-zA-Z]+", "").toUpperCase();
					if(!getNumScale.isEmpty())
						break;
					else
						getNumScale = "N";
				}

				//Parse Graph Plot
				if(!graphPlot.isEmpty())
				{
					//Find Data Points
					Elements graphDataPoints = graphPlot.select(".v-datapoint-group > g");
					Elements graphDataLabel = graphPlot.select(".v-datalabel-group > g");

					int legendCounter = 0;
					for (Element element : graphDataPoints) 
					{		
						int xAxisCounter = 0;
						int elementsToFetch = xAxisLabels.size() + 1;
						Elements bars = element.select("g[data-datapoint-id]:lt("+elementsToFetch+")");
						for (Element bar : bars) 
						{
							//Get the label of each bar
							String id = bar.attr("data-datapoint-id");					
							Element label = graphDataLabel.select("[data-datapoint-id='"+id+"']").first();
							String labelText = label.text();

							//Get the height of each bar
							Element rectangle = bar.select("rect").first();
							Float height = (float) 0.0;
							if(label.text().contains("-"))
								height = Float.parseFloat(rectangle.attr("height")) * -1;
							else
								height = Float.parseFloat(rectangle.attr("height"));

							//Store label in Hashmap
							HashMap<String, String> labelMap = new HashMap<String, String>();
							labelMap.put(legendGroup.get(legendCounter), labelText);
							if (barGraphLabelMap.containsKey(extractedXAxisLabels.get(xAxisCounter))) {
								HashMap<String, String> temp = barGraphLabelMap.get(extractedXAxisLabels.get(xAxisCounter)) ;
								labelMap.putAll(temp);
							}
							barGraphLabelMap.put(extractedXAxisLabels.get(xAxisCounter), labelMap);

							//Store formatted label in Hashmap (Like in Billion, Million)
							Float barLabelFormatted = NumberConverter.changeNumberScale(getNumScale, labelText);
							HashMap<String, Float> labelFormattedMap = new HashMap<String, Float>();
							labelFormattedMap.put(legendGroup.get(legendCounter), barLabelFormatted);
							if (barGraphLabelFormattedMap.containsKey(extractedXAxisLabels.get(xAxisCounter))) {
								HashMap<String, Float> temp = barGraphLabelFormattedMap.get(extractedXAxisLabels.get(xAxisCounter)) ;
								labelFormattedMap.putAll(temp);
							}
							barGraphLabelFormattedMap.put(extractedXAxisLabels.get(xAxisCounter), labelFormattedMap);

							//Store height in Hashmap
							HashMap<String, Float> heightMap = new HashMap<String, Float>();
							heightMap.put(legendGroup.get(legendCounter), height);
							if (barGraphHeightMap.containsKey(extractedXAxisLabels.get(xAxisCounter))) {
								HashMap<String, Float> temp = barGraphHeightMap.get(extractedXAxisLabels.get(xAxisCounter)) ;
								heightMap.putAll(temp);
							}
							barGraphHeightMap.put(extractedXAxisLabels.get(xAxisCounter), heightMap);

							xAxisCounter++;
						}
						legendCounter++;
					}
					System.out.println("Bar Label - " + barGraphLabelMap);
					System.out.println("Bar Height - " + barGraphHeightMap);
				}
				
				//Remove string part from Y-Axis label details
				List<Float> yAxisLabelsDetailsFloat = NumberConverter.changeNumberScale(getNumScale, yAxisLabels);
				//List<Float> yAxisLabelsDetailsFloat = convertListStringToFloat(yAxisLabels);

				//Validate if height and label lies in correct range
				System.out.println();
				System.out.println("---------Verfying Column Chart Labels with their Height--------");
				System.out.println();

				for(int i = 0; i < extractedXAxisLabels.size(); i++)
				{
					String forLabel = extractedXAxisLabels.get(i);
					HashMap<String, String> barLegendForLabel = barGraphLabelMap.get(forLabel);
					HashMap<String, Float> barLegendFormattedForLabel = barGraphLabelFormattedMap.get(forLabel);
					HashMap<String, Float> barHeightForLabel = barGraphHeightMap.get(forLabel);

					for(int j = 0; j < legendGroup.size(); j++)
					{
						String forLegendGroup = legendGroup.get(j);
						String label = barLegendForLabel.get(forLegendGroup);
						float labelFormatted = barLegendFormattedForLabel.get(forLegendGroup);
						float height = barHeightForLabel.get(forLegendGroup);

						int[] barLabelRange = getArrayRangeIndex(yAxisLabelsDetailsFloat, labelFormatted);
						int[] barHeightRange = getArrayRangeIndex(updatedGridLinesHeight, height);

						if(Arrays.equals(barLabelRange,barHeightRange))
						{
							HTMLOutputWriter.insertRow("Graph Rendering", forLegendGroup + " - '" + label + "' for " + xAxisLabels.get(i), "Plotted Correctly", false, 1);
							System.out.println(forLegendGroup + " - '" + label + "' for '" + xAxisLabels.get(i) + "' is plotted correctly on Graph.");
						}
						else
						{
							HTMLOutputWriter.insertRow("Graph Rendering", forLegendGroup + " - '" + label + "' for " + xAxisLabels.get(i), "Not Plotting Correctly", false, 0);
							throw new Exception(forLegendGroup + " - '" + label + "' for '" + xAxisLabels.get(i) + "' is NOT plotted correctly on Graph.");
						}	
					}
					System.out.println();
				}
				System.out.println("-------------------Graph Rendering Validated-------------------");				

				//Assign values to static variables to be used in main class
				xAxis_Category = xAxisCategory;
				xAxis_Label = extractedXAxisLabels;
				legend_Groups = legendGroup;	
				graph_Bars_Labels = barGraphLabelMap;
				//yAxis_Label = yAxisLabels;
				HTMLOutputWriter.closeTable(1);
				return true;
			}
		}
		catch(Exception e)
		{
			HTMLOutputWriter.closeTable(0);
			System.out.println("Exception validateGraphRendering - " + e.getMessage());
			throw new Exception(e.getMessage());
		}
	}

	public HashMap<String, String> getValuesFromPieChart() throws Exception
	{
		System.out.println();
		System.out.println("Getting values from PIE CHART.");
		HashMap<String, String> pieGraphValues = new HashMap<String, String>();
		try
		{
			Document doc = objSeleniumHelper.getJsoupDom();
			Elements graphNode = doc.select("svg");
			Elements graphMain = graphNode.select(".v-m-plot");
			Elements graphPlot = graphMain.select(".v-m-plot");

			//Get Legend groups
			List<String> legendGroups =  getLegendGroup(graphNode);

			//Parse Graph Plot
			if(!graphPlot.isEmpty())
			{
				//Find Data Points
				Elements graphDataPoints = graphPlot.select(".v-datapoint-group > g");
				Elements graphDataLabel = graphPlot.select(".v-datalabel-group > g");

				int counter = 0;
				for (Element element : graphDataPoints) 
				{
					Elements rectangles = element.select("g[data-datapoint-id]");
					for (Element rect : rectangles) 
					{
						String id = rect.attr("data-datapoint-id");                               
						Element label = graphDataLabel.select("[data-datapoint-id='"+id+"']").first();

						if(label != null)
						{
							System.out.println(legendGroups.get(counter) + " - " + label.text());
							pieGraphValues.put(legendGroups.get(counter), label.text());
						}
						else
						{
							System.out.println(legendGroups.get(counter) + " - " + "0.0%");
							pieGraphValues.put(legendGroups.get(counter), "0.0%");
						}
						counter++;
					}
				}                          
			}
		}
		catch(Exception e)
		{
			System.out.println("Exception getValuesFromPieChart - " + e.getMessage());
			throw new Exception("Not able to read Pie Chart values.");
		}
		return pieGraphValues;
	}

	private List<String> getLegendGroup(Elements graphNode)
	{
		//Find Legend groups
		List<String> legendGroup = new ArrayList<String>();
		Elements graphLegendGroup = graphNode.select(".v-m-legendGroup");
		Elements legendItems = graphLegendGroup.select(".v-legend-item");	
		if(!legendItems.isEmpty())
		{
			for (Element element : legendItems) 
			{
				Element group = element.select("text").first();
				String text = group.text();
				if(text.contains("/"))
				{
					text = text.split("/")[1].trim();
				}
				legendGroup.add(text);
				//System.out.println("Text - " + text.text());
				//Element path = element.select("path").first();
				//System.out.println("Bar color - " + path.attr("fill"));
			}
		}
		//System.out.println("Legend Group - " + legendGroup);
		return legendGroup;
	}

	private List<Float> getGridLinesHeight(Elements graphPlot)
	{
		List<Float> gridLinesHeight = new ArrayList<Float>();
		if(!graphPlot.isEmpty())
		{
			//Find Gridlines
			Elements graphGridlines = graphPlot.select(".v-gridline-group > .v-gridline");	
			for (Element element : graphGridlines) 
			{				
				Element ele = element.select("line").first();
				gridLinesHeight.add(Float.parseFloat(ele.attr("y1")));
			}
		}
		//System.out.println("Grid Lines Height - " + gridLinesHeight);
		return gridLinesHeight;
	}

	private List<Float> updateGridLinesHeight(List<String> yAxisLabelsDetails, List<Float> gridLinesHeight)
	{
		ArrayList<Float> updatedGridLinesHeight = null;
		if(yAxisLabelsDetails.get(0).equalsIgnoreCase("0"))
		{
			Collections.reverse(gridLinesHeight);
			updatedGridLinesHeight = new ArrayList<Float>(gridLinesHeight);
		}
		else
		{
			Collections.reverse(yAxisLabelsDetails);
			Collections.reverse(gridLinesHeight);

			int indexOfZero = yAxisLabelsDetails.indexOf("0");
			updatedGridLinesHeight = new ArrayList<Float>(gridLinesHeight.subList(0, gridLinesHeight.size() - indexOfZero)); 

			for(int i=0; i< indexOfZero; i++)
			{
				Float t = gridLinesHeight.get(i+1);
				updatedGridLinesHeight.add(0, t * -1);
			}
		}
		System.out.println("Grid Lines Height - " + updatedGridLinesHeight);	
		return updatedGridLinesHeight;
	}

	private String getXAxisCategory(Elements graphXAxis)
	{
		//Parse X-Axis
		String category = null;		
		if(!graphXAxis.isEmpty())
		{			
			//Find title of X-Axis
			Element xAxisTitle = graphXAxis.select(".v-m-axisTitle > .viz-axis-title > text").first();
			if(xAxisTitle != null)
			{
				category = xAxisTitle.text();
				System.out.println("X-Axis Category - " + category);
			}				
		}
		return category;
	}

	private List<String> getXAxisLabels(Elements graphXAxis)
	{
		List<String> xAxisLabelsDetails = new ArrayList<String>();
		if(!graphXAxis.isEmpty())
		{
			//Find labels on X-Axis
			Elements xAxisBody = graphXAxis.select(".v-m-axisBody");
			Elements xAxisLabels = xAxisBody.select(".v-label-group > .viz-axis-label");
			for (Element element : xAxisLabels) 
			{
				Element ele = element.select("g > text").first();
				xAxisLabelsDetails.add(ele.text());
			}
		}
		System.out.println("X-Axis Label - " + xAxisLabelsDetails);
		return xAxisLabelsDetails;
	}

	private List<String> extractXAxisLabels(List<String> xAxisLabelsDetails)
	{
		List<String> labelValues = new ArrayList<String>();
		for(String label : xAxisLabelsDetails)
		{
			String regex = "\\(([^()]+)\\)";
			Pattern ptrn = Pattern.compile(regex);
	        Matcher match = ptrn.matcher(label);
	        String value = "";
	        while (match.find()) {
	        	value = match.group(1);
	        }
			//String temp = label.substring(label.indexOf("(")+1, label.indexOf(")"));
			labelValues.add(value);
		}
		System.out.println("Extracted X-Axis Label - " + labelValues);
		return labelValues;
	}

	/*
	private String getYAxisCategory(Elements graphYAxis)
	{
		//Parse Y-Axis
		String category = null;
		if(!graphYAxis.isEmpty())
		{
			//Find title of Y-Axis
			Element yAxisTitle = graphYAxis.select(".v-m-axisTitle > .viz-axis-title > text").first();
			if(yAxisTitle != null)
			{
				category = yAxisTitle.text();
				System.out.println("Y-Axis Category - " + category);
			}
		}
		return category;
	}
	 */

	private List<String> getYAxisLabels(Elements graphYAxis)
	{
		List<String> yAxisLabelsDetails = new ArrayList<String>();
		if(!graphYAxis.isEmpty())
		{
			//Find labels on Y-Axis
			Elements yAxisBody = graphYAxis.select(".v-m-axisBody");
			Elements graphGridlinesLabel = yAxisBody.select(".v-label-group > .viz-axis-label");
			for (Element element : graphGridlinesLabel) 
			{								
				Element ele = element.select("text").first();				
				yAxisLabelsDetails.add(ele.text());
			}
		}
		//System.out.println("Y-Axis Label - " + yAxisLabelsDetails);	
		return yAxisLabelsDetails;
	}

	/*
	private List<Float> convertListStringToFloat(List<String> stringList) 
	{
		List<Float> floatList = new ArrayList<Float>();
		for(String string : stringList)
		{
			float temp = Float.valueOf(string.replaceAll("[^-\\d.]+|\\.(?!\\d)", ""));
			floatList.add(temp);
		}
		return floatList;
	}
	 */
	
	private int[] getArrayRangeIndex(List<Float> list, float numberToCheck)
	{
		int[] arrayIndex = new int[2];
		for(int k = 0; k < list.size() - 1; k++)
		{
			float grt = list.get(k);
			float less = list.get(k + 1);
			if(numberToCheck >= grt && numberToCheck <= less)
			{
				arrayIndex[0] = k;
				arrayIndex[1] = k + 1;
				break;
			}
		}
		return arrayIndex;
	}
}
