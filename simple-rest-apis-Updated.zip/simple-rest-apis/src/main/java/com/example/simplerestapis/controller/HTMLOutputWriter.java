package com.example.simplerestapis.controller;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import org.openqa.selenium.WebDriver;

public class HTMLOutputWriter {

	private static FileWriter fw;
	private static WebDriver driver = null;
	private static String executionPath = null;

	public static void createHTML(WebDriver getDriver) 
	{
		try 
		{
			driver = getDriver;
			executionPath = System.getProperty("user.dir") + "\\src\\main\\resources\\";
			String timeStamp = getTimeStamp();
			String location = executionPath + "Graphica_Execution_Logs_" + timeStamp + ".html";
			String title = "Graphica Execution Logs";  

			fw = new FileWriter(location);
			fw.write("<!DOCTYPE html>");
			fw.write("<html>");
			fw.write("<head>");
			fw.write("<title>"+title+"</title>");
			fw.write(" <style>"
					+ "body{"
					+ "         //background-color:#c2d4e7;"
					+ "         background-color:#fafafa;"
					+ "}"
					+ "table{"
					+ "         padding-right:0px;"
					+ "         padding-left:0px;"
					+ "         margin-left:0px;"
					+ "         margin-right:0px;"
					+ "         //border:5px inset #345543;"
					+ "}"
					+ "td,th{"
					+ "         height:30px;"
					+ "         width:205px;"
					+ "         text-align:left;"
					+ "         padding-left:5px;"
					+ "         padding-bottom:5px;"
					+ "         font-family:Arial;"
					+ "         //border-bottom:1.2px solid #A8A8A8;"
					+ "         border-bottom:1.2px solid #427cac;"
					+ "}"
					+ "tr{"
					+ "         padding:20px;"
					+ "}"
					+ "tr:nth-child(odd){"
					+ "         background-color:#FFFFFF;"
					+ "}"
					+ ".success{"
					+ "         background-color:#078500;"
					+ "         height:18px;"
					+ "         width:18px;"
					+ "}"
					+ ".fail{"
					+ "         border:4px solid #c40404;"
					+ "         border-radius:15px;"
					+ "         height:18px;"
					+ "         width:18px;"
					+ "         color:#d14747"
					+ "}"
					+ "tr:nth-child(even){"
					+ "         background-color:#F0F0F0;"
					+ "         //background-color:#eff4f9;"   
					+ "}"
					+ ""
					+ "</style>"
					+ "<script>"
					+ "         function toggleTable(id,id1)"
					+ "         {"
					+ "               var x = document.getElementById(id);"
					+ "               var y = document.getElementById(id1);"
					+ "               if(x.style.display==\"none\")"
					+ "               {"
					+ "                     x.style.display = \"block\";"
					+ "                     y.value = \"-\";"
					+ "               }"
					+ "               else"
					+ "               {"
					+ "                     x.style.display = \"none\";"
					+ "                     y.value = \"+\";"
					+ "               }     "
					+ "         }"
					+ "</script>"
					+ "");
			
			fw.write("</head>");
			fw.write("<body><div>");
			fw.write("<div align=\"center\">"
					+ "<h2>"+title+"</h2>"
					+ "</div>"
					+ "<table align=\"center\" width=\"1024\">"
					+ "<tr><th><div align=\"center\">Step Name</div></th>"
					+ "<th><div align=\"center\">Input data</div></th>"
					+ "<th><div align=\"center\">Exported Data</div></th>"
					+ "<th><div align=\"center\">Status</div></th>"
					+ "<th><div align=\"center\">Screenshot</div></th></tr>"
					+ "</table><br>");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void createTable(String name)
	{
		try {
			String m[] = name.split(" ");
			String p = "";
			String q = "";
			for(int i=0;i<m.length;i++)
			{
				p+=m[i];
				q+=p+"34";
			}
			fw.write("<table align=\"center\" width=\"1024\">");
			fw.write("<tr><th colspan=4>"
					+ "<input type=\"button\" value=\"+\" id=\""+q+"\" style=\"background-color:#ffffff; font-size:22px;color:#2557a3;border:none;\" onclick=\"toggleTable('"+p+"','"+q+"')\" />"
					+ ""+name+"</th></tr><table align=\"center\" id="+p+" width='1024' style='display:none'>");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Takes input Action, input data, transaction data, status
	 * @throws Exception 
	 */
	public static void insertRow(String action, String input, String output, boolean screenshot, int status) throws Exception
	{
		try
		{	
			fw.write("<tr><td>"+action+"</td><td>"+input+"</td>");
			if(screenshot)
			{
				String timeStamp = getTimeStamp();
				String filePath = executionPath +"screenshot\\Graphica_Execution_SS_" + timeStamp + ".png";
				Screenshot.takeScreenshot(driver, filePath);	

				if(status == 1)
					fw.write("<td>"+output+"</td><td><div align=\"center\"><div class=\"success\"></div></div></td><td><a target='blank' href='"+filePath+"'>Screenshot</a></td></tr>");
				else
					fw.write("<td>"+output+"</td><td><div align=\"center\"><div align=\"center\" class=\"fail\">x</div></div></td><td><a target='blank' href='"+filePath+"'>Screenshot</a></td></tr>");
			}
			else
			{
				if(status == 1)
					fw.write("<td>"+output+"</td><td><div align=\"center\"><div class=\"success\"></div></div></td><td>No Screenshot</td></tr>");
				else
					fw.write("<td>"+output+"</td><td><div align=\"center\"><div align=\"center\" class=\"fail\">x</div></div></td><td>No Screenshot</td></tr>");
			}
		} 
		catch (IOException e) {
			// TODO Auto-generated catch block
			throw new Exception("Report update error  - " + e.getMessage());
		}
	}

	public static void closeTable(int status)
	{
		try {
			fw.write("</table>");
			if(status==1)
				fw.write("<table align=\"center\" width='1024'><tr><th colspan='4'>Overall Status</th><div align=\"center\"><th><div align=\"center\" style=\"color:#078500;\">PASSED</div></th></div></tr></table><br><br>");
			else
				fw.write("<table align=\"center\" width='1024'><tr><th colspan='4'>Overall Status</th><th><div align=\"center\" style=\"color:#c40404\">FAILED</div></th></tr></table><br><br>");

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void closeHTML()
	{
		try {
			fw.write("</div></body></html>");
			fw.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void cleanup() {
		try {
			fw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static String getTimeStamp()
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
		Timestamp ts = new Timestamp(System.currentTimeMillis());
		String timeStamp = sdf.format(ts); 
		return timeStamp;
	}
}

